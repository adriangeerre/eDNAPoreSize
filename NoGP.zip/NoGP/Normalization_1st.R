# Normalization of best Bitscore/E-value

# Libraries
library(edgeR)
library(magrittr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(tidyr)

# Data
setwd("/datos/GenomeDK/blast_1st_merged/")
f <- list.files()
dfs <- lapply(f, function(x) read.delim(x, header=F) %>% mutate(file = substr(x,0,4)))

# Raw Counts
dfc <- lapply(dfs, function(x) x %>% group_by(V2,V16,file) %>% summarise(count = n()))
dfc_short <- lapply(dfc, function(x) x %>% ungroup() %>% rename(accession=V2) %>% select(accession,count,file))
dfcm <- Reduce(function(...) merge(..., all=T), dfc_short)
dfcm <- dfcm %>% spread(file,count)
dfcm[is.na(dfcm)] <- 0
rownames(dfcm) <- dfcm$accession
dfcm <- dfcm %>% select(-accession)
dfcm <- dfcm %>% select(A0_2,B0_2,C0_2,A1_2,B1_2,C1_2,A5_0,B5_0,C5_0,A8_0,B8_0,C8_0)

# Remove unlikely hits (full row is <2)
keep <- rowSums(dfcm) > 1
dfcm <- dfcm[keep,]
boxplot(dfcm)
boxplot(log2(dfcm+1))
# 
# Normalize library sizes (Comparison of normalized counts)
#   https://www.biorxiv.org/content/biorxiv/suppl/2015/09/26/021741.DC2/021741-1.pdf
# Compute of: 
#   sizeFactor, i.e. a scaling coefficient that applies to raw counts.
#   normalization factor, i.e. a scaling coefficient that applies to library sizes.

# Transform
df <- log2(dfcm+1)
group <- c('0.2','0.2','0.2','1.2','1.2','1.2','5.0','5.0','5.0','8.0','8.0','8.0')
d <- DGEList(counts=df, group=group)

# CPM
cpm <- cpm(DGEList(dfcm), log=F)
boxplot(log2(cpm+1))

keep <- rowSums(cpm) > 1
dfcm <- dfcm[keep,]

# RLE (Relative Log Expression)
#   Calculates scaling factors using the ratio between gene abundances and their geometric mean
rle <- calcNormFactors(d, method="RLE")
rle.counts <- rle$counts
for (i in 1:12) {
  rle.counts[,i] <- rle$counts[,i] * rle$samples$norm.factors[i]
}
boxplot(rle.counts)

# TMM (Trimmed Mean of M-Values)
#   Calculates scaling factors based on robust analysis of the difference in relative abundance between samples.
tmm <- calcNormFactors(d, method="TMM")
tmm.counts <- tmm$counts
for (i in 1:12) {
  tmm.counts[,i] <- tmm$counts[,i] * tmm$samples$norm.factors[i]
}
boxplot(tmm.counts)

# Upper quantile (One or more are zero - Doesn't work)
# upq <- calcNormFactors(d, method="upperquartile")

# Save Tables
write.table(dfcm, file="../raw.counts.tsv", quote=F, sep="\t")
write.table(cpm, file="../cpm.counts.tsv", quote=F, sep="\t")
write.table(rle.counts, file="../rle.counts.tsv", quote=F, sep="\t")
write.table(tmm.counts, file="../tmm.counts.tsv", quote=F, sep="\t")


# # DESeq2
# library(DESeq2)
# samples <- data.frame(run = c("A0_2","B0_2","C0_2","A1_2","B1_2","C1_2","A5_0","B5_0","C5_0","A8_0","B8_0","C8_0"), replicate = rep(c(1,2,3), 4), condition = c(rep("0.2", 3), rep("1.2", 3), rep("5.0", 3), rep("8.0", 3)))
# dds <- DESeqDataSetFromMatrix(countData = dfcm, colData = samples, design = ~ replicate + condition)
# dds <- DESeq(dds)
# deseq <- sizeFactors(dds)
# c <- counts(dds, normalized=TRUE) # Equal to RLE

# PCA
pcaplot <- function(x) {
  mat  = t(x)
  pca  = prcomp(mat, scale=F)
  summary(pca)
  col = c(rep("blue3",3), rep("red3",3), rep("green3",3), rep("orange3",3))
  col.leg = c("blue3", "red3", "green3", "orange3")
  nam = c("A0_2","B0_2","C0_2","A1_2","B1_2","C1_2","A5_0","B5_0","C5_0","A8_0","B8_0","C8_0")
  legend = c("0.2","1.2","5.0","8.0")
  aval  = pca$sdev^2
  cvar  = pca$rotation %*% diag(pca$sdev)
  #screeplot(pca, npcs=min(10, length(pca$sdev)), type="lines", col="red", main="Screeplot")
  pos = c(rep(1,length(nam)-1), 3)
  xs  = pca$x[,1]
  ys  = pca$x[,2]
  
  xlab = paste("PC1 (", summary(pca)$importance[2,1]*100, " %)", sep='')
  ylab = paste("PC2 (", summary(pca)$importance[2,2]*100, " %)", sep='')
  plot(pca$x[,1:2], pch=19, col=col, main="Two-dimensional PCA (Hits counts)", xlab=xlab, ylab=ylab)
  abline(h=0, v=0, lty=2, col=8)
  text(xs, ys, labels=nam, pos=pos)
}

pcaplot(log2(dfcm+1))
pcaplot(cpm)
pcaplot(rle.counts)
pcaplot(tmm.counts)
