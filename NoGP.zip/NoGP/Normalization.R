# RLE normalization (env: Bioconductor)
# Example:
#   https://davetang.org/muse/2011/01/24/normalisation-methods-for-dge-data/
#   https://hbctraining.github.io/DGE_workshop/lessons/02_DGE_count_normalization.html

# Libraries
library(edgeR)
library(magrittr)
library(dplyr)
library(ggplot2)
library(tidyr)

# Data
f <- list.files()
dfs <- lapply(f, function(x) read.csv2(x, sep=",", header=TRUE) %>% mutate(file = substr(x,0,4)))
dfs <- lapply(dfs, function(x) x %>% unite("taxonomy", superkingdom:kingdom:phylum:class:order:family:genus:species, sep=","))
dfs <- lapply(dfs, function(x) x %>% group_by(taxonomy,file) %>% summarise(count = n()) %>% arrange(taxonomy))
dfs <- Reduce(function(...) merge(..., all=T), dfs)
dfs <- dfs %>% spread(file,count)
dfs[is.na(dfs)] <- 0
rownames(dfs) <- dfs$taxonomy 
df <- dfs %>% select(-taxonomy)

# Mask taxonomy
m <- data.frame(taxonomy = dfs$taxonomy, mask = paste("tax",1:length(dfs$taxonomy),sep=""))
rownames(df) <- m$mask

# Transform
df <- log2(df+1)
group <- c('0.2','0.2','0.2','1.2','1.2','1.2','5.0','5.0','5.0','8.0','8.0','8.0')
d <- DGEList(counts=df, group=group)

# RLE (Relative Log Expression)
rle <- calcNormFactors(d, method="RLE")
rle_norm <- estimateCommonDisp(rle)
rle_test <- exactTest(rle_norm, pair = c("0.2","8.0")) # Differential found taxonomies
table(p.adjust(rle_test$table$PValue, method="BH")<0.05)

# TMM
tmm <- calcNormFactors(d, method="TMM")
tmm_norm <- estimateCommonDisp(tmm)
tmm_test <- exactTest(tmm_norm, pair = c("0.2","8.0"))
table(p.adjust(tmm_test$table$PValue, method="BH")<0.05)

# DE-Taxonomy
get_de <- function(x, pvalue){
  my_i <- p.adjust(x$PValue, method="BH") < pvalue
  row.names(x)[my_i]
}

tax_rle <- m$taxonomy[m$mask %in% get_de(rle_test$table, 0.05)]
tax_tmm <- m$taxonomy[m$mask %in% get_de(tmm_test$table, 0.05)]


      