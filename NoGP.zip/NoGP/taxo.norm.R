# Libraries
library(tidyverse)
library(taxizedb)
library(reshape2)

# Counts
df <- read.delim("/datos/GenomeDK/rle.counts.tsv")
# "../raw.counts.tsv"
# "../cpm.counts.tsv"
# "../rle.counts.tsv"
# "../tmm.counts.tsv"

# Remove 4 Accessions without taxid
rmacc <- c("2GYA_0", "2HGR_C", "2MS1_B", "3AN2_I")
keep <- !rownames(df) %in% rmacc
df <- df[keep,]

# Taxonomy
taxonom <- read.delim("/datos/GenomeDK/blast_1st/acc2tax.tsv", header=F)
accdups <- read.delim("/datos/GenomeDK/blast_1st/accdups.mrca.tsv", header=T)
colnames(taxonom) <- c("accession", "taxids")

# Modify multiple entries taxids to mrca taxid
sc <- grepl(";", taxonom$taxids)
tax <- taxonom[!sc,]
tax_sc <- taxonom[sc,]
tax_sc <- merge(accdups, tax_sc, by="taxids") %>% select(c(accession,mrca)) %>% rename(taxids=mrca)
taxonom <- rbind(tax,tax_sc) %>% arrange(accession)

# Reduce taxonomy to rownames
keep <- taxonom$accession %in% rownames(df)
taxonom <- taxonom[keep,]

# Get full taxonomy from taxid
l <- classification(unique(taxonom$taxids))
table(is.na(l)) # 247 values do not have a classification.
l <- Filter(function(a) any(!is.na(a)), l) # Remove NAs; class list.
lf <- lapply(l, function(x) x %>% filter(rank %in% c("superkingdom","kingdom","phylum","class","order","family","genus","species")) %>% select(rank,name) %>% spread(rank,name))

for (i in 1:length(names(lf))) {
  lf[[i]] <- lf[[i]] %>% mutate(taxids = names(lf)[i])
} # Add taxid to taxonomy

fulltax <- Reduce(function(...) merge(..., all=T), lf) # Takes long time DO NOT EXECUTE AGAIN
fulltax <- fulltax %>% select(c("taxids","superkingdom","kingdom","phylum","class","order","family","genus","species")) %>% arrange(superkingdom, kingdom, phylum, class, order, family, genus)

write.table(fulltax, file="/datos/GenomeDK/full.taxonomy.tsv", quote=F, sep="\t", row.names=F)

# Add taxid in count table
tf <- merge(taxonom, fulltax, by="taxids")
df <- df %>% mutate(accession = rownames(df))
df <- merge(df, tf, by="accession")

write.table(df, file="/datos/GenomeDK/counts.taxonomy.tsv", quote=F, sep="\t", row.names=F)

# Transform log count into real count "(base^log2(number) = first number) -1"
df[,2:13] <- (2^df[,2:13])-1
df[,2:13][df[,2:13] < 1] <- 0 # Values below one are convert to 0
df[,2:13]<- round(df[,2:13], 0)

write.table(df, file="/datos/GenomeDK/roundcounts.taxonomy.tsv", quote=F, sep="\t", row.names=F)

# Test
melt(df[,c(15,2:13)] %>% drop_na() %>% group_by(superkingdom) %>% summarise_if(is.numeric, sum)) %>% group_by(variable) %>% mutate(perc = (value / sum(value)*100)) %>% ggplot() + geom_col(aes(x=variable,y=perc,fill=superkingdom))

